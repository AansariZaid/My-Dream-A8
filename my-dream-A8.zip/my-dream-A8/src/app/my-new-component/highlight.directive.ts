import { Directive,ElementRef , Input} from '@angular/core';


@Directive({
  selector: '[appHighlight]'
})
export class HighlightDirective {


   el: ElementRef

   @Input() value: string;
   constructor(el: ElementRef) {
      
      this.el=el;
     // el.nativeElement.style.backgroundColor = 'yellow';
   }

  // Life Cycle Hook 
ngOnInit() {
        console.log("directive : ", +this.value);
        this.el.nativeElement.style.color =this.value;
    }

}
