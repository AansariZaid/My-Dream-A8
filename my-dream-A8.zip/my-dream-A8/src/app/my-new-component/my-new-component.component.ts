import { Component, OnInit } from '@angular/core';
import { Customer } from './customermodel';
import {MyserviceService} from './myservice.service'

@Component({
  selector: 'app-my-new-component',
  templateUrl: './my-new-component.component.html',
  styleUrls: ['./my-new-component.component.css']
})
export class MyNewComponentComponent {

  getData:string;
  jsonData:any;
  custArray:Array<Customer> = new Array();

// define back model here

   model = new Customer('', 0);

   constructor(private _httpService:MyserviceService)  { }


// write  the event to create customer for Airport

submitted = false;

  onSubmit() {

    this.submitted = true;
     }

// write createCustomer event here

 createCustomer(){

  	console.log("customer creation here-->");

  	// Add customer in Customer Array using push event.
     this.custArray.push(new Customer(this.model.name, this.model.age));
     console.log(JSON.stringify(this.custArray));

  }


// Call the Userdetail service here


onTestGet(){

    this._httpService.getUserDetails()
    .subscribe(
          data =>{ this.getData=JSON.stringify(data);
                    this.jsonData = data;
          },
          error =>alert(error),
          ()=>console.log("finished")

      );
}



}
