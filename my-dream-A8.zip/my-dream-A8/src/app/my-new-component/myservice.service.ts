import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { map } from "rxjs/operators";

@Injectable({
  providedIn: "root"
})
export class MyserviceService {
  constructor(private http: HttpClient) {}

  // GET promise impl for fatch the data

  getUserDetails() {
    return this.http.get("https://jsonplaceholder.typicode.com/users").pipe(map(res => res));
  }
}
