import { TestpipePipe } from './testpipe.pipe';

describe('TestpipePipe', () => {
  it('create an instance', () => {
    const pipe = new TestpipePipe();
    expect(pipe).toBeTruthy();
  });
});
